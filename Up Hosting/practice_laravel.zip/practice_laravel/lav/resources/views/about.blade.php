@extends('template.base')
@section('content')
    <h1>About</h1>
    <p>Ini adalah praktikum Desain Pemrograman Web 2 yang mempelajari framework PHP yaitu Laravel</p>
@endsection